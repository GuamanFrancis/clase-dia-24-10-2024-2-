//sprint o 
//dilimitacion de lao sequisitos a cumplir
//Estructura genereal de las carpetas del proyecto
//Diseño de las colecciones de datos para mongodb
//Asignacion de roles para casa usuario

//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
////dElimitacion de lOS REquisitos a cumplir
//El backend disponde de un conjunto de rutas publicas y privadas
//El backend permite el registro e inicio de sesioón de ususaios administradores
//El backend permite gestionar tours
//El backend permite visualizar y contratar tours 
//Efigura mas descripcion 

//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
//Estructura genereal de las carpetas del proyecto
//El proyecto utilizo VSCODE + JS + EXPRESS + ARCHIVO + DIRECTORIOS
//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

//Diseño de las colecciones de datos para mongodb
//En una base de datos no sql las tablas se llaman colecciones y los registros son  documentos

// BDD              TABLAS                    REGISTROS
//NOSQL             COLECCIONES              DOCUMENTOS}

//2 colecciones  
//base de datos Json-server luego lo podemos cambiar por mongodb, mysql, etc

//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
//Asignacion de roles para casa usuario 
//Administrador o Conductor el va hacer Gestionar tours
//Cliente el va a hacer  de visualizar y contratar un tour
//END DEL SPRINT NUMERO 0 


//SPRINT 1 GESTION DE TOURS 
//Creacion de tareas para 

//"start": "node src/index.js",

//Creacion de 

