import tourModel from '../models/tour.js'


const getAlltourController = async(req,res) =>{
    try {
        const tours =  await tourModel.getAllToursModel()
        res.status(200).json(tours)
    } catch (error) {
        console.log(error)
    }


}

export{
    getAlltourController
}//hago la exportacion de esta manera por que ya tengo mas metodos y ya no me sirve el export default
