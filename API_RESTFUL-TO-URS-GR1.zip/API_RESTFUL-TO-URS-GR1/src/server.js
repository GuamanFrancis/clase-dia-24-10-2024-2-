//solo configuraciones de nuestro servidor

//requerir modulos  

import express from 'express'
import router from './routers/tour_routes.js'

//COMMONJS

//INICIALIZACUIONES

const app = express()

//VARIABLES
app.set('port',process.env.port || 3000)

//MIDDLEWARES

app.use(express.json())

//RUTAS PRINCIPAL

app.get('/',(req,res)=>{
    res.send("OK")
})
//RUTAS PARA EL TOUR
app.use('/api',router)


//RUTAS PARA EL USER


//RUTAS PARA EL BOOKING


//Exportar la instcncia de app
export default app
//cada vez que exporto algo tengo que importar 