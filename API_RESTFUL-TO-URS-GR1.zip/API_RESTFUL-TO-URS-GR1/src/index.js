//esta es el motor que arramque de al 
import app from './server.js'
app.listen(3000,()=>{
    console.log("Server ON")
})