const tourModel = {


    async getAllToursModel(){

       try {
        const peticion = await fetch('http://localhost:400/tours')
        const tours = await peticion.json()
        return tours 
       } catch (error) {
        console.log(error)
        
       }

    }
}

export default tourModel